<? snippet('header') ?>

<main>
  <section class="initial">
    <h1>Index Journal</h1>
    <h1>Identity politics dissolves the identity of the artwork</h1>
  </section>

  <figure class="wipe" style="background-image: url('assets/images/02.jpg')"></figure>
  <section class="spacer"></section>

  <div class="text-block">
    <section class="call">
      <h3>CALL FOR PAPERS</h3>
      <p>INDEX JOURNAL is calling for papers for its inaugural issue IDENTITY. Submissions are encouraged from art historians of all specialisations.</p>
      <h3>SUBMISSIONS NOW CLOSED</h3>
    </section>
  </div>

</main>
</body>
</html>
