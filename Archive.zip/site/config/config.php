<?

return [
  'debug' => true,
  'markdown' => [
    'extra' => true
  ]
];
?>
