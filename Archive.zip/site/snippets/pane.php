<div class="pane">
  <span class="pane-close">Close</span>
  <header>
    <h1><a href=".">INDEX JOURNAL</a>, <span>Issue No. 1 IDENTITY</span></h1>
  </header>
  <div class="pane-inner">
    <figure>
      <img src="assets/images/Giambattista_Tiepolo_The_Banquet_of_Cleopatra.jpg" alt="Giambattista Tiepolo – The Banquet of Cleopatra">
      <figcaption>Giambattista Tiepolo, <em>The banquet of Cleopatra</em> (1743–44); oil on canvas, 250.3 × 357.0 cm. <a target="_blank" href="https://www.ngv.vic.gov.au/explore/collection/work/4409/">National Gallery of Victoria, Melbourne</a>.</figcaption>
    </figure>
  </div>
</div>
