<?php

return [
    'email' => 'hi@public-office.info',
    'language' => 'en',
    'name' => 'Paul Mylecharane',
    'role' => 'admin'
];