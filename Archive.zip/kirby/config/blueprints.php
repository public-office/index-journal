<?php

return [
    'files/default' => __DIR__ . '/blueprints/file.yml',
    'pages/default' => __DIR__ . '/blueprints/page.yml',
    'site'          => __DIR__ . '/blueprints/site.yml'
];
